#pragma once
#ifndef MAINMENU_H_INCLUDED
#define MAINMENU_H_INCLUDED
#include "constants.hpp"
#include "bfUI.hpp"
using std::string;
extern sf::RenderWindow appWindow;
//extern sf::Font font;
class LoadingScreen;
class Data;
//class MegaTexture;
//extern MegaTexture uiMega;
class State;
class MainMenu: public sf::Drawable
{
private:
	std::vector<sf::Text> texts;
	std::vector<sf::Text> dateTexts;
	static sf::String VideoModeToString(const sf::VideoMode& v) {return my_to_string(v.width)+"x"+my_to_string(v.height);}
	const Data& data;
public:
    MainMenu(const Data& data, const State& state);
    void init(const State&);
    int16_t mapSize;
    int8_t state;
    bfUI::Button newGameButton, loadGameButton, settingsButton, escapeButton;
    bfUI::Button upButton, downButton, saveSettingsButton, revertSettingsButton, graphicSettingsButton, languageSettingsButton;
    bfUI::CheckBox fullscreenCheckBox;
    sf::Text numOfPlayers, fullscreenName;
    bfUI::Button playerNumButton[8], mapSizeButton[8], generateMapButton;
    virtual void draw(sf::RenderTarget& target, sf::RenderStates states) const;
    void actualizeNames();
    std::string chooseSave(State& state, LoadingScreen& ls,const std::string& path, const std::string& ext);
    sf::VideoMode chooseResolution(State& state, LoadingScreen& ls, const std::vector<sf::VideoMode>& validModes);
};

#endif // MAINMENU_H_INCLUDED
