#pragma once
#ifndef GUICLASSES_H_INCLUDED
#define GUICLASSES_H_INCLUDED
#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>
extern sf::RenderWindow appWindow;
//extern sf::Texture sliderTexture, barTexture;
class State;
class Data;
namespace bfUI
{
	extern sf::Texture uiBackground;
    extern sf::Sound clickSound;
    extern sf::SoundBuffer clickSoundBuffer;
class Button: public sf::Drawable
{
protected:
    bool isActive;
    static const Data* data;
public:
    // It should NOT be directly used outside this and MegaTexture
    sf::RectangleShape icon, activeIcon;
    //
    sf::Color unactiveColor, activeColor;
    Button(bool is=true): isActive(is) {}
    sf::Text text;
    static void setData(const Data& data) {Button::data=&data;}
    void setActive(bool is){isActive=is;icon.setFillColor(unactiveColor);}
    void updateTextTransform();
    void setText(const sf::String& str, const sf::Font& font=sf::Font(), const sf::Color& color=sf::Color::Black);
    void setCharacterSize(float size) {text.setCharacterSize(size);}
    bool getActive () const {return isActive;}
    bool wasPressed(const State& state);
    virtual void draw(sf::RenderTarget& target, sf::RenderStates states) const {target.draw(icon,states);target.draw(text,states);}
    void setTexture (const sf::Texture& tex, const sf::Texture& activeTex=sf::Texture(), bool resetRect=false);
    void setSize (const sf::Vector2f& v) {setSize(v.x,v.y);}
    void setSize (float x, float y);
    const sf::Vector2f& getSize() const {return icon.getSize();}
    void setScale(const sf::Vector2f& v) {icon.setScale(v.x,v.y);}
    void setScale (float x, float y) {icon.setScale(x,y);activeIcon.setScale(x,y);}
    void setOutlineColor (sf::Color color) {icon.setOutlineColor(color);activeIcon.setOutlineColor(color);}
    void setOutlineThickness (float thickness) {icon.setOutlineThickness(thickness);activeIcon.setOutlineThickness(thickness);}
    void setUnactiveColor() {icon.setFillColor(unactiveColor);activeIcon.setFillColor(unactiveColor);}
    void setActiveColor() {icon.setFillColor(activeColor);activeIcon.setFillColor(activeColor);}
    void setPosition (float x, float y) {icon.setPosition(x,y);activeIcon.setPosition(x,y);}
    void setPosition (const sf::Vector2f &position) {setPosition(position.x,position.y);}
};
class CheckBox: public Button
{
private:
    bool isChecked;
public:
    CheckBox(bool is=true, bool ch=false): Button(is), isChecked(ch) {}
    virtual void draw(sf::RenderTarget& target, sf::RenderStates states) const {if(!isChecked)target.draw(icon,states);else target.draw(activeIcon,states);target.draw(text,states);}
    bool getChecked() const {return isChecked;}
    void setChecked(bool ch);
    bool checkPressed(const State& state);

};
///NOT USED
class Bar: public sf::Drawable, public sf::Transformable
{
protected:
    static const Data* data;
    sf::Sprite background;
    void setTexture (const sf::Texture &texture, bool resetRect=false);
    float fillPercentage; //0-min, 1-max
public:
    sf::RectangleShape fillRect; sf::Text text;
    Bar() {fillRect.setFillColor(sf::Color::White);}
    static void setData(const Data& data) {Bar::data=&data;}
    void initTextures();
    ///Drawable
    virtual void draw(sf::RenderTarget& target, sf::RenderStates states) const override;
    ///Transformable
    void setPosition (float x, float y);
    void setPosition (const sf::Vector2f &position) {setPosition(position.x,position.y);}
    const sf::Transform& getInverseTransform () const {return background.getInverseTransform();}
    const sf::Vector2f& getOrigin () const {return background.getOrigin();}
    const sf::Vector2f& getPosition () const {return background.getPosition();}
    float getRotation () const {return background.getRotation();}
    const sf::Vector2f& getScale () const {return background.getScale();}
    const sf::Transform& getTransform () const {return background.getTransform();}
    void move (float offsetX, float offsetY);
    void move (const sf::Vector2f & offset) {move(offset.x,offset.y);}
    void rotate (float angle) {setRotation(angle+background.getRotation());}
    void scale (float factorX, float factorY) {setScale(background.getScale().x*factorX,background.getScale().y*factorY);}
    void scale (sf::Vector2f& factor) {scale(factor.x,factor.y);}
    void setOrigin (float x, float y);
    void setOrigin (sf::Vector2f& origin) {setOrigin(origin.x,origin.y);}
    void setRotation (float angle);
    void setScale(float x, float y);
    void setScale(const sf::Vector2f &factors) {setScale(factors.x,factors.y);}
    sf::FloatRect getLocalBounds () const {return background.getLocalBounds();}
    sf::FloatRect gettGlobalBounds () const {return background.getGlobalBounds();}
    ///Sprite
    const sf::Texture* getTexture () const {return background.getTexture();}
    const sf::IntRect& getTextureRect () const {return background.getTextureRect();}
    void setTextureRect (const sf::IntRect &rectangle) {background.setTextureRect(rectangle);}
    void setBackgroundColor (const sf::Color &color) {background.setColor(color);}
    const sf::Color &getBackgroundColor () const {return background.getColor();}
    ///Text
    void setString(const sf::String &string){text.setString(string);}
    void setFont (const sf::Font &font) {text.setFont(font);}
    void setCharacterSize (unsigned int size) {text.setCharacterSize(size);}
    void setTextColor(const sf::Color& color) {text.setFillColor(color);}
    ///Rect
    void setFillColor(const sf::Color& color) {fillRect.setFillColor(color);}
    const sf::Color& getFillColor() const {return fillRect.getFillColor();}
    float getFillPercentage() const {return fillPercentage;}
    void setFillPercentage(float per);
    virtual ~Bar() {}
};

class Slider: public Bar
{
    int16_t maxValue, value;
    bool isActive;
public:
    sf::Sprite slider;
    Slider(const Data& data): Bar() {fillRect.setFillColor(sf::Color::White);}
    Slider(): Bar() {fillRect.setFillColor(sf::Color::White);}
    void setFillPercentage(float per);
    bool getActive() const {return isActive;}
    void setActive(bool pr) {isActive=pr;}
    bool moveUpdate(const State& state); //true if value was changed
    virtual void draw(sf::RenderTarget& target, sf::RenderStates states) const override;
    void initTextures();
    void setMaxValue(int16_t mVal) {maxValue=mVal;}
    void setValue(int16_t val);
    int16_t getMaxValue() const {return maxValue;}
    int16_t getValue() const {return value;}
};
class InsertText: public sf::Drawable, public sf::Transformable
{
private:
    sf::Text text;
public:
    ///sf::Drawable
    void draw(sf::RenderTarget& target, sf::RenderStates states) const {target.draw(text,states);}
    ///sf::Transformable
    void setPosition (float x, float y) {text.setPosition(x,y);};
    void setPosition (const sf::Vector2f &position) {text.setPosition(position.x,position.y);}
    const sf::Transform& getInverseTransform () const {return text.getInverseTransform();}
    const sf::Vector2f& getOrigin () const {return text.getOrigin();}
    const sf::Vector2f& getPosition () const {return text.getPosition();}
    float getRotation () const {return text.getRotation();}
    const sf::Vector2f& getScale () const {return text.getScale();}
    const sf::Transform& getTransform () const {return text.getTransform();}
    void move (float offsetX, float offsetY) {text.move(offsetX,offsetY);}
    void move (const sf::Vector2f & offset) {move(offset.x,offset.y);}
    void rotate (float angle) {text.rotate(angle);}
    void scale (float factorX, float factorY) {text.scale(factorX,factorY);}
    void scale (sf::Vector2f& factor) {scale(factor.x,factor.y);}
    void setOrigin (float x, float y) {text.setOrigin(x,y);}
    void setOrigin (sf::Vector2f& origin) {text.setOrigin(origin.x,origin.y);}
    void setRotation (float angle) {text.setRotation(angle);}
    void setScale(float x, float y) {text.setScale(x,y);};
    void setScale(const sf::Vector2f &factors) {text.setScale(factors.x,factors.y);}
    sf::FloatRect getLocalBounds () const {return text.getLocalBounds();}
    sf::FloatRect getGlobalBounds () const {return text.getGlobalBounds();}
    ///TEXT functions
    sf::Vector2f findCharacterPos(std::size_t index) {return text.findCharacterPos(index);}
    unsigned int getCharacterSize() const {return text.getCharacterSize();}
    const sf::Color& getFillColor() const {return text.getFillColor();}
    const sf::Font* getFont() const {return text.getFont();}
    const sf::Color& getOutlineColor() const {return text.getOutlineColor();}
    float getOutlineThickness() const {return text.getOutlineThickness();}
    const sf::String& getString() const {return text.getString();}
    sf::Uint32 getStyle() const {return text.getStyle();}
    void setCharacterSize(unsigned int size) {text.setCharacterSize(size);}
    void setFillColor(const sf::Color& color) {text.setFillColor(color);}
    void setFont(const sf::Font& font) {text.setFont(font);}
    void setOutlineColor(const sf::Color color) {text.setOutlineColor(color);}
    void setOutlineThickness (float thickness) {text.setOutlineThickness(thickness);}
    void setString(const sf::String& string) {text.setString(string);}
    void setStyle(sf::Uint32 style) {text.setStyle(style);}
    #if SFML_VERSION_MINOR>=5
    float getLetterSpacing() const {return text.getLetterSpacing();}
    float getLineSpacing() const {return text.getLineSpacing();}
    void setLetterSpacing(float spacingFactor) {text.setLetterSpacing(spacingFactor);}
    void setLineSpacing(float spacingFactor) {text.setLineSpacing(spacingFactor);}
    #endif
    ///characteristic functions
};
}
#endif // GUICLASSES_H_INCLUDED
