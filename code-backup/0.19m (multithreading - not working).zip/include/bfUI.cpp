#include "bfUI.hpp"
#include "constants.hpp"
#include "Data.hpp"
#include <cmath>
sf::SoundBuffer bfUI::clickSoundBuffer;
sf::Sound bfUI::clickSound(bfUI::clickSoundBuffer);
const Data* bfUI::Button::data=nullptr;
const Data* bfUI::Bar::data=nullptr;
void bfUI::Button::setTexture (const sf::Texture& tex, const sf::Texture& activeTex, bool resetRect)
{
    icon.setTexture(&tex, resetRect);
    if(activeTex.getSize().x>0)
        icon.setTexture(&activeTex);
    else
        icon.setTexture(&tex, resetRect);
}
void bfUI::Button::setSize (float x, float y)
{
    const sf::Texture* iconT=icon.getTexture();
    const sf::Texture* aIconT=activeIcon.getTexture();
    icon=sf::RectangleShape({x,y});
    icon.setTexture(iconT,false);
    activeIcon=sf::RectangleShape({x,y});
    activeIcon.setTexture(aIconT,false);
}

void bfUI::CheckBox::setChecked(bool ch)
{
    isChecked=ch;
}
bool bfUI::CheckBox::checkPressed(const State& state, sf::Vector2i mapPressPosition)
{
    if(wasPressed(state, mapPressPosition))
    {
        //isChecked=!isChecked;
        return true;
    }
    return false;
}
void bfUI::Bar::initTextures()
{
    if(!data)
        throw("Trying to access to nullptr\n");
    setTexture(bfUI::Bar::data->getBarTexture());
}
void bfUI::Slider::initTextures()
{
    if(!data)
        throw("Trying to access to nullptr\n");
    slider.setTexture(data->getSliderTexture());
    Bar::initTextures();
}
void bfUI::Slider::setValue(int16_t val)
{
    if(!data)
        throw("Trying to access to nullptr\n");
    auto barSize=data->getBarTexture().getSize();
    auto slidSize=data->getSliderTexture().getSize();
    value=val;
    fillPercentage=(float)val/(float)maxValue;
    fillRect.setSize(sf::Vector2f(background.getTexture()->getSize().x*(float)val/(float)maxValue,background.getTexture()->getSize().y));
    slider.setPosition(background.getPosition()+sf::Vector2f((float)val/(float)maxValue*barSize.x*background.getScale().x-slidSize.x*slider.getScale().x*.5f,.0f));
}
bool bfUI::Slider::moveUpdate(const State& state, sf::Vector2i relativeMousePosition)
{
    if(!isActive) return false;
    sf::FloatRect rect=background.getGlobalBounds();
    if(relativeMousePosition.x>rect.left+rect.width || relativeMousePosition.y>rect.top+rect.height
       || relativeMousePosition.x<rect.left || relativeMousePosition.y<rect.top) return false;
    //this->icon.setFillColor(activeColor);
    if(state.event.type!=sf::Event::MouseButtonPressed)
        return false;
    int newValue=std::round(((relativeMousePosition.x-rect.left)/rect.width)*maxValue);
    if(newValue==getValue()) return false;
    setValue(newValue);
    return true;
}
void bfUI::Bar::draw(sf::RenderTarget& target, sf::RenderStates states) const
{
    target.draw(fillRect,states);
    target.draw(background,states);
    target.draw(text,states);
}
void bfUI::Slider::draw(sf::RenderTarget& target, sf::RenderStates states) const
{
    target.draw(fillRect,states);
    target.draw(background,states);
    target.draw(text,states);
    target.draw(slider,states);
}
void bfUI::Bar::setTexture (const sf::Texture &texture, bool resetRect)
{
    background.setTexture(texture,resetRect);
    fillRect.setSize(sf::Vector2f(texture.getSize().x*fillPercentage,texture.getSize().y));
    fillRect.setPosition(fillRect.getPosition().x+(fillRect.getSize().x-background.getTexture()->getSize().x)*fillRect.getScale().x,fillRect.getPosition().y);
}
void bfUI::Bar::setPosition (float x, float y)
{
    text.setPosition(x+text.getPosition().x-background.getPosition().x,y+text.getPosition().y-background.getPosition().y);
    background.setPosition(x,y);
    fillRect.setPosition(x,y);
}
void bfUI::Bar::move (float offsetX, float offsetY)
{
    background.move(offsetX,offsetY);
    fillRect.move(offsetX,offsetY);
    text.move(offsetX,offsetY);
}
void bfUI::Bar::setOrigin (float x, float y)
{
    background.setOrigin(x,y);fillRect.setOrigin(x,y);text.setOrigin(x,y);
}
void bfUI::Bar::setRotation (float angle)
{
    background.setRotation(angle);
    fillRect.setRotation(angle);
    sf::Vector2f tmpPos=text.getPosition();
    text.move(tmpPos.x+background.getPosition().x,-tmpPos.y+background.getPosition().y);
    text.setRotation(angle);
    text.move(tmpPos.x-background.getPosition().x,tmpPos.y-background.getPosition().y);
}
void bfUI::Bar::setScale(float x, float y)
{
    background.setScale(x,y);fillRect.setScale(x,y);text.setScale(x,y);
}
void bfUI::Bar::setFillPercentage(float per)
{
    fillPercentage=per;
    fillRect.setSize(sf::Vector2f(background.getTexture()->getSize().x*per*background.getScale().x/background.getScale().y
            ,background.getTexture()->getSize().y));
}
bool bfUI::Button::wasPressed(const State& state, sf::Vector2i tmpMousePos)
{
    if(!isActive) {icon.setFillColor(unactiveColor);return false;}
    sf::FloatRect rect=icon.getGlobalBounds();
    if(tmpMousePos.x>rect.left+rect.width || tmpMousePos.y>rect.top+rect.height
       || tmpMousePos.x<rect.left || tmpMousePos.y<rect.top)
        {this->icon.setFillColor(unactiveColor);return false;}
    this->icon.setFillColor(activeColor);
    if(state.event.type!=sf::Event::MouseButtonPressed)
        return false;
    if(bfUI::clickSound.getStatus()!=sf::Sound::Status::Playing)
    {
        bfUI::clickSound.play();
    }
    return true;
}
void bfUI::Button::setText(const sf::String& str, const sf::Font& font, const sf::Color& color)
{
    text.setString(str);
    text.setFont(font);
    text.setFillColor(color);
}
void bfUI::Button::updateTextTransform()
{
    sf::Vector2f tmpDiff = sf::Vector2f((icon.getGlobalBounds().width-text.getGlobalBounds().width)*.5f,(icon.getGlobalBounds().height-text.getGlobalBounds().height)*.25f);
    text.setPosition(icon.getPosition()+tmpDiff);
    //text.setScale(icon.getScale());
}
