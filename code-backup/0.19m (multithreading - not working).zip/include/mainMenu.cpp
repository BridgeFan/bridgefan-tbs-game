#include "mainMenu.hpp"
#include "constants.hpp"
#include "LoadingScreen.hpp"
#include "megaTexture.hpp"
#include "Data.hpp"
#include <filesystem>
#include <iostream>
#include <fstream>
#include <algorithm>
#include <chrono>

namespace fs=std::filesystem;

MainMenu::MainMenu(const Data& data, const State& state): data(data)
{
    //if(init(state))
    //    throw std::exception();
}
void MainMenu::init(const State& mainState)
{
    state=0;
	float uiScale = appWindow.getSize().y/1080.f;
    actualizeNames();
    ls.actualizeSize();
	///NEW GAME BUTTON
    newGameButton.setSize(1080.f*.4f,1080.f*.1f);
    newGameButton.setPosition(appWindow.getSize().x/2.f-1080.f*.2f*uiScale,appWindow.getSize().y*.05f);
    newGameButton.unactiveColor=sf::Color(196,196,196);
    newGameButton.activeColor=sf::Color::White;
    newGameButton.setTexture(bfUI::uiBackground);
    newGameButton.setOutlineColor(sf::Color::Black);
    newGameButton.setOutlineThickness(5.f);
    newGameButton.setScale(uiScale,uiScale);
    newGameButton.text.setFont(data.getFont());
    newGameButton.text.setFillColor(sf::Color::Black);
    newGameButton.setCharacterSize(60.f*uiScale);
    newGameButton.updateTextTransform();
	///LOAD GAME BUTTON
    loadGameButton.setSize(1080.f*.4f,1080.f*.1f);
    loadGameButton.setPosition(appWindow.getSize().x/2.f-1080.f*.2f*uiScale,appWindow.getSize().y*.2f);
    loadGameButton.unactiveColor=sf::Color(196,196,196);
    loadGameButton.activeColor=sf::Color::White;
    loadGameButton.setTexture(bfUI::uiBackground);
    loadGameButton.setOutlineColor(sf::Color::Black);
    loadGameButton.setOutlineThickness(5.f);
    loadGameButton.setScale(uiScale,uiScale);
    loadGameButton.text.setFont(data.getFont());
    loadGameButton.text.setFillColor(sf::Color::Black);
    loadGameButton.setCharacterSize(60.f*uiScale);
    loadGameButton.updateTextTransform();
	///SETTINGS BUTTON
    settingsButton.setSize(1080.f*.4f,1080.f*.1f);
    settingsButton.setPosition(appWindow.getSize().x/2.f-1080.f*.2f*uiScale,appWindow.getSize().y*.35f);
    settingsButton.unactiveColor=sf::Color(196,196,196);
    settingsButton.activeColor=sf::Color::White;
    settingsButton.setTexture(bfUI::uiBackground);
    settingsButton.setOutlineColor(sf::Color::Black);
    settingsButton.setOutlineThickness(5.f);
    settingsButton.setScale(uiScale,uiScale);
    settingsButton.text.setFont(data.getFont());
    settingsButton.text.setFillColor(sf::Color::Black);
    settingsButton.setCharacterSize(60.f*uiScale);
    settingsButton.updateTextTransform();
	///ESCAPE BUTTON
    escapeButton.setSize(1080.f*.4f,1080.f*.1f);
    escapeButton.setPosition(appWindow.getSize().x/2.f-1080.f*.2f*uiScale,appWindow.getSize().y*.8f);
    escapeButton.unactiveColor=sf::Color::Red;
    escapeButton.activeColor=sf::Color(255,196,196);
    escapeButton.setOutlineColor(sf::Color::Black);
    escapeButton.setOutlineThickness(5.f);
    escapeButton.setScale(uiScale,uiScale);
    escapeButton.text.setFont(data.getFont());
    escapeButton.text.setFillColor(sf::Color::Black);
    escapeButton.setCharacterSize(60.f*uiScale);
    escapeButton.updateTextTransform();
    ///UP BUTTON
    //if(!upTexture.loadFromFile("data/up.png"))
	//	return EXIT_FAILURE;
    upButton.setSize(64.f,64.f);
    data.getUiMegaTexture().assignTexture(upButton,upID,upID+1);
    upButton.unactiveColor=sf::Color::White;
    upButton.activeColor=sf::Color(196,196,196);
    upButton.setPosition(appWindow.getSize().x*.8f,appWindow.getSize().y*.45f);
    upButton.setActive(false);
    upButton.setOutlineThickness(0.f);
    upButton.setScale(uiScale,uiScale);
    ///DOWN BUTTON
    downButton.setSize(64.f,64.f);
    data.getUiMegaTexture().assignTexture(downButton,downID,downID+1);
    downButton.unactiveColor=sf::Color(196,196,196);
    downButton.activeColor=sf::Color::White;
    downButton.setPosition(appWindow.getSize().x*.8f,appWindow.getSize().y*.55f);
    downButton.setActive(false);
    downButton.setOutlineThickness(0.f);
    downButton.setScale(uiScale,uiScale);
	///NUM OF PLAYERS TEXT
    numOfPlayers.setPosition(appWindow.getSize().x/2.f-1080.f*.2f*uiScale,appWindow.getSize().y*.05f);
    numOfPlayers.setCharacterSize(80.f*uiScale);
    numOfPlayers.setFillColor(sf::Color::White);
    numOfPlayers.setFont(data.getFont());
	///PLAYER NUM BUTTONS (NEW GAME)
    for(int i=0;i<8;i++)
    {
        playerNumButton[i].setSize(1080.f*.08f,1080.f*.1f);
        playerNumButton[i].setPosition(appWindow.getSize().x/2.f-1080.f*(.4f-i*.1f)*uiScale,appWindow.getSize().y*.35f);
		playerNumButton[i].unactiveColor=sf::Color(196,196,196);
		playerNumButton[i].activeColor=sf::Color::White;
		playerNumButton[i].setTexture(bfUI::uiBackground);
        playerNumButton[i].setOutlineColor(sf::Color::Black);
        playerNumButton[i].setOutlineThickness(5.f);
        playerNumButton[i].setScale(uiScale,uiScale);
        playerNumButton[i].setText(my_to_string(i+1),data.getFont());
        playerNumButton[i].setCharacterSize(60.f*uiScale);
        playerNumButton[i].updateTextTransform();
    }
	///MAP SIZE BUTTONS (NEW GAME)
    for(int i=0;i<8;i++)
    {
        mapSizeButton[i].setSize(1080.f*.08f,1080.f*.1f);
        mapSizeButton[i].setPosition(appWindow.getSize().x/2.f-1080.f*(.4f-i*.1f)*uiScale,appWindow.getSize().y*.5f);
		mapSizeButton[i].unactiveColor=sf::Color(196,196,196);
		mapSizeButton[i].activeColor=sf::Color::White;
		mapSizeButton[i].setTexture(bfUI::uiBackground);
        mapSizeButton[i].setOutlineColor(sf::Color::Black);
        mapSizeButton[i].setOutlineThickness(5.f);
        mapSizeButton[i].setScale(uiScale,uiScale);
        mapSizeButton[i].setText(my_to_string((i+1)*32),data.getFont());
        mapSizeButton[i].setCharacterSize(60.f*uiScale);
        mapSizeButton[i].updateTextTransform();
    }
	///GENERATE MAP BUTTON (NEW GAME)
    generateMapButton.setSize(1080.f*.4f,1080.f*.1f);
    generateMapButton.setPosition(appWindow.getSize().x/2.f-1080.f*.2f*uiScale,appWindow.getSize().y*.65f);
	generateMapButton.unactiveColor=sf::Color(196,196,196);
	generateMapButton.activeColor=sf::Color::White;
	generateMapButton.setTexture(bfUI::uiBackground);
    generateMapButton.setOutlineColor(sf::Color::Black);
    generateMapButton.setOutlineThickness(5.f);
    generateMapButton.setScale(uiScale,uiScale);
    generateMapButton.text.setFont(data.getFont());
    generateMapButton.text.setFillColor(sf::Color::Black);
    generateMapButton.setCharacterSize(60.f*uiScale);
    generateMapButton.updateTextTransform();
    ///GRAPHICS SETTING BUTTON
    graphicSettingsButton.setSize(1080.f*.4f,1080.f*.1f);
    graphicSettingsButton.setPosition(appWindow.getSize().x/2.f-1080.f*.2f*uiScale,appWindow.getSize().y*.2f);
    graphicSettingsButton.unactiveColor=sf::Color(196,196,196);
    graphicSettingsButton.activeColor=sf::Color::White;
    graphicSettingsButton.setTexture(bfUI::uiBackground);
    graphicSettingsButton.setOutlineColor(sf::Color::Black);
    graphicSettingsButton.setOutlineThickness(5.f);
    graphicSettingsButton.setScale(uiScale,uiScale);
    graphicSettingsButton.text.setFont(data.getFont());
    graphicSettingsButton.text.setFillColor(sf::Color::Black);
    graphicSettingsButton.setCharacterSize(60.f*uiScale);
    graphicSettingsButton.updateTextTransform();
    ///LANGUAGE SETTINGS BUTTON
    languageSettingsButton.setSize(1080.f*.4f,1080.f*.1f);
    languageSettingsButton.setPosition(appWindow.getSize().x/2.f-1080.f*.2f*uiScale,appWindow.getSize().y*.35f);
    languageSettingsButton.unactiveColor=sf::Color(196,196,196);
    languageSettingsButton.activeColor=sf::Color::White;
    languageSettingsButton.setTexture(bfUI::uiBackground);
    languageSettingsButton.setOutlineColor(sf::Color::Black);
    languageSettingsButton.setOutlineThickness(5.f);
    languageSettingsButton.setScale(uiScale,uiScale);
    languageSettingsButton.text.setFont(data.getFont());
    languageSettingsButton.text.setFillColor(sf::Color::Black);
    languageSettingsButton.setCharacterSize(60.f*uiScale);
    languageSettingsButton.updateTextTransform();
    ///FULLSCREEN CHECK BOX
    fullscreenCheckBox.setSize(64.f,64.f);
    data.getUiMegaTexture().assignTexture(fullscreenCheckBox,checkBoxOff,checkBoxOn);
    fullscreenCheckBox.setChecked(mainState.isFullscreen);
    fullscreenCheckBox.setPosition(appWindow.getSize().x/2.f+1080.f*.3f*uiScale,appWindow.getSize().y*.5f);
    fullscreenCheckBox.unactiveColor=sf::Color(196,196,196);
    fullscreenCheckBox.activeColor=sf::Color::White;
    ///FULLSCREEN TEXT
    fullscreenName.setPosition(appWindow.getSize().x/2.f-1080.f*.5f*uiScale,appWindow.getSize().y*.5f);
    fullscreenName.setCharacterSize(80.f*uiScale);
    fullscreenName.setFillColor(sf::Color::Black);
    fullscreenName.setOutlineColor(sf::Color::White);
    fullscreenName.setOutlineThickness(2.f);
    fullscreenName.setFont(data.getFont());
    ///SAVE SETTINGS BUTTON
    saveSettingsButton.setSize(1080.f*.4f,1080.f*.1f);
    saveSettingsButton.setPosition(appWindow.getSize().x/2.f-1080.f*.2f*uiScale,appWindow.getSize().y*.65f);
	saveSettingsButton.unactiveColor=sf::Color(196,196,196);
	saveSettingsButton.activeColor=sf::Color::White;
	saveSettingsButton.setTexture(bfUI::uiBackground);
    saveSettingsButton.setOutlineColor(sf::Color::Black);
    saveSettingsButton.setOutlineThickness(5.f);
    saveSettingsButton.setScale(uiScale,uiScale);
    saveSettingsButton.text.setFont(data.getFont());
    saveSettingsButton.text.setFillColor(sf::Color::Black);
    saveSettingsButton.setCharacterSize(60.f*uiScale);
    saveSettingsButton.updateTextTransform();
    ///REVERT SETTINGS BUTTON
    revertSettingsButton.setSize(1080.f*.4f,1080.f*.1f);
    revertSettingsButton.setPosition(appWindow.getSize().x/2.f-1080.f*.2f*uiScale,appWindow.getSize().y*.8f);
    revertSettingsButton.unactiveColor=sf::Color::Red;
    revertSettingsButton.activeColor=sf::Color(255,196,196);
    revertSettingsButton.setOutlineColor(sf::Color::Black);
    revertSettingsButton.setOutlineThickness(5.f);
    revertSettingsButton.setScale(uiScale,uiScale);
    revertSettingsButton.text.setFont(data.getFont());
    revertSettingsButton.text.setFillColor(sf::Color::Black);
    revertSettingsButton.setCharacterSize(60.f*uiScale);
    revertSettingsButton.updateTextTransform();
}
void MainMenu::draw(sf::RenderTarget& target, sf::RenderStates states) const
{
    if(state==0) //main menu
    {
        target.draw(newGameButton, states);
        target.draw(loadGameButton, states);
        target.draw(settingsButton, states);
        target.draw(escapeButton, states);
    }
    else if(state==1) //new game menu
    {
        target.draw(numOfPlayers, states);
        for(int i=0;i<8;i++)
        {
            target.draw(playerNumButton[i], states);
            target.draw(mapSizeButton[i], states);
        }
        target.draw(generateMapButton, states);
        target.draw(escapeButton, states);
    }
    else if(state==2 || state==5)
	{
        target.draw(escapeButton, states);
	}
    else if(state==3)
	{
        target.draw(revertSettingsButton, states);
        target.draw(fullscreenCheckBox, states);
        target.draw(fullscreenName, states);
        target.draw(saveSettingsButton, states);
        target.draw(graphicSettingsButton, states);
        target.draw(languageSettingsButton, states);
	}
	else if(state==4)
	{
        target.draw(escapeButton, states);
	}
}
std::string MainMenu::chooseSave(State& state, const std::string& path, const std::string& ext)
{
    std::vector<std::pair<std::string, std::filesystem::file_time_type> > names;
	//std::string path = "./saves/";
	//std::string ext = ".sav";
    for (const auto & entry : std::filesystem::directory_iterator(path))
		if(entry.path().extension()==ext)
		{
            names.push_back({entry.path().stem().string(),std::filesystem::last_write_time(entry)});
		}

    if(this->state==2)
        std::sort(names.begin(),names.end(),[](const auto& a, const auto& b)
			{if(a.second!=b.second) return a.second>b.second; return a.first<b.first;});
    else
        std::sort(names.begin(),names.end(),[](const auto& a, const auto& b)
			{return a.first<b.first;});

    std::vector<std::string> info;
	if(this->state==2)
	{
        std::fstream file;
        for(std::size_t i=0u;i<names.size();i++)
        {
            std::string fileName=path+names[i].first+ext;
            file.open(fileName, std::fstream::in | std::ifstream::binary);
            if(file.good())
            {
                info.push_back(my_to_string(load(file))+std::string("x")+my_to_string(load(file)));
            }
            else
            {
                names.erase(names.begin()+i);
                i--;
            }
            file.close();
        }
    }
	texts.clear();
	dateTexts.clear();
	int savesPage=0;
	//int savesPageSize=std::ceil(names.size()/14.f);
	float scale=appWindow.getSize().y/1080.f;
	for(int i=0;i<std::min(14,(int)names.size());i++)
	{
		texts.push_back(sf::Text(names[i].first,data.getFont(),60));
		texts[i].setFillColor(sf::Color::Black);
		texts[i].setOutlineThickness(6.f);
		texts[i].setScale(scale,scale);
		texts[i].setOutlineColor(sf::Color::Transparent);
		sf::FloatRect fr=texts[i].getLocalBounds();
		texts[i].setOrigin(fr.left + fr.width/2.0f, .0f);
		texts[i].setPosition(sf::Vector2f(appWindow.getSize().x*.4f,i*scale*60.f));
		if(this->state==2)
		{
            dateTexts.push_back(sf::Text(info[i],data.getFont(),60));
            dateTexts[i].setFillColor(sf::Color::Black);
            dateTexts[i].setOutlineThickness(6.f);
            dateTexts[i].setScale(scale,scale);
            dateTexts[i].setOutlineColor(sf::Color::Transparent);
            fr=dateTexts[i].getLocalBounds();
            dateTexts[i].setOrigin(fr.left + fr.width/2.0f, .0f);
            dateTexts[i].setPosition(sf::Vector2f(appWindow.getSize().x*.6f,i*scale*60.f));
        }
        else
            texts[i].move(appWindow.getSize().x*.1f,.0f);
	}
    upButton.setActive(true);
    downButton.setActive(true);
	bool isMouseButtonPressed=false;
	sf::Vector2f tmpMousePos;
	while(true)
	{
		tmpMousePos=appWindow.mapPixelToCoords(sf::Mouse::getPosition(appWindow));
		while (appWindow.pollEvent(state.event))
        {
            if(state.event.type==sf::Event::Closed)
			{
				isMouseButtonPressed=false;
				appWindow.close();
				this->state=0;
				upButton.setActive(true);
				downButton.setActive(true);
				return std::string();
			}
            else if(state.event.type==sf::Event::MouseButtonReleased)
                isMouseButtonPressed=true;
        }
        for(std::size_t i=0u;i<texts.size();i++)
		{
            if(inBounds(tmpMousePos,texts[i].getGlobalBounds()))
			{
				texts[i].setOutlineColor(sf::Color::Yellow);
				if(isMouseButtonPressed && sf::Mouse::isButtonPressed(sf::Mouse::Left))
				{
					this->state=0;
					upButton.setActive(true);
					downButton.setActive(true);
					return path+texts[i].getString().toAnsiString()+ext;
				}
			}
			else
			{
				texts[i].setOutlineColor(sf::Color::Transparent);
			}
		}
        if(isMouseButtonPressed && escapeButton.wasPressed(state, (sf::Vector2i)tmpMousePos))
		{
			isMouseButtonPressed=false;
			upButton.setActive(true);
			downButton.setActive(true);
			return std::string();
		}
        if(isMouseButtonPressed && upButton.wasPressed(state, (sf::Vector2i)tmpMousePos))
		{
			isMouseButtonPressed=false;
			if(savesPage>0)
			{
				savesPage--;
				for(int i=0;i<14;i++)
					if(i+savesPage*14<(int)names.size())
					{
						texts[i].setString(names[i+savesPage*14].first);
						sf::FloatRect fr=texts[i].getLocalBounds();
						texts[i].setOrigin(fr.left + fr.width/2.0f, .0f);
						texts[i].setPosition(sf::Vector2f(appWindow.getSize().x*.4f,i*scale*60.f));
						if(this->state==2)
						{
                            dateTexts[i].setString(info[i+savesPage*14]);
                            fr=dateTexts[i].getLocalBounds();
                            dateTexts[i].setOrigin(fr.left + fr.width/2.0f, .0f);
                            dateTexts[i].setPosition(sf::Vector2f(appWindow.getSize().x*.6f,i*scale*60.f));
                        }
					}
					else
					{
						texts[i].setString("");
						if(this->state==2)
                            dateTexts[i].setString("");
					}
			}
		}
        if(isMouseButtonPressed && downButton.wasPressed(state, (sf::Vector2i)tmpMousePos))
		{
			isMouseButtonPressed=false;
			if(savesPage<std::ceil(names.size()/14.f)-1)
			{
				savesPage++;
				for(int i=0;i<14;i++)
					if(i+savesPage*14<(int)names.size())
					{
						texts[i].setString(names[i+savesPage*14].first);
						sf::FloatRect fr=texts[i].getLocalBounds();
						texts[i].setOrigin(fr.left + fr.width/2.0f, .0f);
						texts[i].setPosition(sf::Vector2f(appWindow.getSize().x*.4f,i*scale*60.f));
						if(this->state==2)
						{
                            dateTexts[i].setString(info[i+savesPage*14]);
                            fr=dateTexts[i].getLocalBounds();
                            dateTexts[i].setOrigin(fr.left + fr.width/2.0f, .0f);
                            dateTexts[i].setPosition(sf::Vector2f(appWindow.getSize().x*.6f,i*scale*60.f));
                        }
					}
					else
					{
						texts[i].setString("");
						if(this->state==2)
                            dateTexts[i].setString("");
					}
			}
		}
		appWindow.clear();
		appWindow.draw(ls);
		appWindow.draw(*this);
		for(std::size_t i=0u;i<texts.size();i++)
			appWindow.draw(texts[i]);
        if(this->state==2)
		{
            for(std::size_t i=0u;i<dateTexts.size();i++)
                appWindow.draw(dateTexts[i]);
        }
		if(savesPage>0)
			appWindow.draw(upButton);
		if(savesPage<std::ceil(names.size()/14.f)-1)
			appWindow.draw(downButton);
		appWindow.display();
	}
}
sf::VideoMode MainMenu::chooseResolution(State& state, const std::vector<sf::VideoMode>& validModes)
{
    std::vector<sf::Text> texts;
	texts.clear();
	int savesPage=0;
	float scale=appWindow.getSize().y/1080.f;
	for(int i=0;i<std::min(14,(int)validModes.size());i++)
	{
		texts.push_back(sf::Text(VideoModeToString(validModes[i]),data.getFont(),60));
		texts[i].setFillColor(sf::Color::Black);
		texts[i].setOutlineThickness(6.f);
		texts[i].setScale(scale,scale);
		texts[i].setOutlineColor(sf::Color::Transparent);
		sf::FloatRect fr=texts[i].getLocalBounds();
		texts[i].setOrigin(fr.left + fr.width/2.0f, .0f);
		texts[i].setPosition(sf::Vector2f(appWindow.getSize().x*.5f,i*scale*60.f));
	}
    upButton.setActive(true);
    downButton.setActive(true);
	bool isMouseButtonPressed=false;
	sf::Vector2f tmpMousePos;
	while(true)
	{
		tmpMousePos=appWindow.mapPixelToCoords(sf::Mouse::getPosition(appWindow));
		while (appWindow.pollEvent(state.event))
        {
            if(state.event.type==sf::Event::Closed)
			{
				isMouseButtonPressed=false;
				appWindow.close();
				this->state=0;
				upButton.setActive(true);
				downButton.setActive(true);
				return sf::VideoMode();
			}
            else if(state.event.type==sf::Event::MouseButtonReleased)
                isMouseButtonPressed=true;
        }
        for(std::size_t i=0u;i<texts.size();i++)
		{
            if(inBounds(tmpMousePos,texts[i].getGlobalBounds()))
			{
				texts[i].setOutlineColor(sf::Color::Yellow);
				if(isMouseButtonPressed && sf::Mouse::isButtonPressed(sf::Mouse::Left))
				{
					this->state=0;
					upButton.setActive(true);
					downButton.setActive(true);
					return validModes[i+savesPage*14];
				}
			}
			else
			{
				texts[i].setOutlineColor(sf::Color::Transparent);
			}
		}
        if(isMouseButtonPressed && escapeButton.wasPressed(state, (sf::Vector2i)tmpMousePos))
		{
			isMouseButtonPressed=false;
			upButton.setActive(true);
			downButton.setActive(true);
			return sf::VideoMode();
		}
        if(isMouseButtonPressed && upButton.wasPressed(state, (sf::Vector2i)tmpMousePos))
		{
			isMouseButtonPressed=false;
			if(savesPage>0)
			{
				savesPage--;
				for(int i=0;i<14;i++)
					if(i+savesPage*14<(int)validModes.size())
					{
						texts[i].setString(VideoModeToString(validModes[i+savesPage*14]));
						sf::FloatRect fr=texts[i].getLocalBounds();
						texts[i].setOrigin(fr.left + fr.width/2.0f, .0f);
						texts[i].setPosition(sf::Vector2f(appWindow.getSize().x*.5f,i*scale*60.f));
					}
					else
					{
						texts[i].setString("");
					}
			}
		}
        if(isMouseButtonPressed && downButton.wasPressed(state, (sf::Vector2i)tmpMousePos))
		{
			isMouseButtonPressed=false;
			if(savesPage<std::ceil(validModes.size()/14.f)-1)
			{
				savesPage++;
				for(int i=0;i<14;i++)
					if(i+savesPage*14<(int)validModes.size())
					{
						texts[i].setString(VideoModeToString(validModes[i+savesPage*14]));
						sf::FloatRect fr=texts[i].getLocalBounds();
						texts[i].setOrigin(fr.left + fr.width/2.0f, .0f);
						texts[i].setPosition(sf::Vector2f(appWindow.getSize().x*.5f,i*scale*60.f));
					}
					else
					{
						texts[i].setString("");
					}
			}
		}
		appWindow.clear();
		appWindow.draw(ls);
		appWindow.draw(*this);
		for(std::size_t i=0u;i<texts.size();i++)
			appWindow.draw(texts[i]);
        if(this->state==2)
		{
            for(std::size_t i=0u;i<dateTexts.size();i++)
                appWindow.draw(dateTexts[i]);
        }
		if(savesPage>0)
			appWindow.draw(upButton);
		if(savesPage<std::ceil(validModes.size()/14.f)-1)
			appWindow.draw(downButton);
		appWindow.display();
	}
}
void MainMenu::actualizeNames()
{
    newGameButton.text.setString(Lang("MAIN_MENU_NEW_GAME"));
    loadGameButton.text.setString(Lang("MAIN_MENU_LOAD_GAME"));
    settingsButton.text.setString(Lang("MAIN_MENU_SETTINGS"));
    escapeButton.text.setString(Lang("MAIN_MENU_EXIT"));
    numOfPlayers.setString(Lang("MAIN_MENU_NUMBER_OF_PLAYERS"));
    generateMapButton.text.setString(Lang("MAIN_MENU_GENERATE"));
    fullscreenName.setString(Lang("MAIN_MENU_FULLSCREEN"));
    saveSettingsButton.text.setString(Lang("MAIN_MENU_SETTINGS_SAVE"));
    revertSettingsButton.text.setString(Lang("MAIN_MENU_SETTINGS_REVERT"));
    graphicSettingsButton.text.setString(Lang("MAIN_MENU_SETTINGS_GRAPHICS"));
    languageSettingsButton.text.setString(Lang("MAIN_MENU_SETTINGS_LANGUAGE"));
}
